import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Simulador de tragamonedas inspirado en el Problem I – ICPC World Finals 2025.
 * Gestiona {@code n} ruedas con una secuencia compartida de símbolos de colores.
 * El jackpot ocurre cuando todas las ruedas muestran el mismo símbolo.
 *
 * <p>Las posiciones son base 1; valores fuera de rango se ajustan al límite más cercano.
 * En modo invisible la lógica funciona pero no se actualiza el canvas ni se muestran diálogos.
 *
 * <p>Ciclo 2: agrega {@code swap}, {@code lock}, {@code unlock},
 * {@code spin(wheel, steps)} y {@code spin(String[])}.
 *
 * @author BlancoS-GarzonR
 * @version 2.0
 */
public class SlotMachine {

    private static final int WHEEL_GAP    = 10;
    private static final int MARGIN       = 20;
    private static final int WHEEL_Y      = 55;
    private static final int CANVAS_H     = 210;
    private static final int MIN_CANVAS_W = 220;

    private final ArrayList<String> symbolColors;
    private final ArrayList<Wheel>  wheels;
    private final SlotMachineView   view;
    private boolean visible;
    private boolean lastOk;

    /**
     * Crea una máquina vacía e invisible.
     */
    public SlotMachine() {
        symbolColors = new ArrayList<String>();
        wheels       = new ArrayList<Wheel>();
        view         = new SlotMachineView(MIN_CANVAS_W, CANVAS_H);
        visible      = false;
        lastOk       = true;
    }

    // ------------------------------------------------------------------ ruedas

    /**
     * Agrega una rueda en la posición indicada (clamped a {@code [1, n+1]}).
     * La rueda hereda todos los símbolos existentes.
     *
     * @param pos posición de inserción (base 1)
     */
    public void addWheel(int pos) {
        int index = clamp(pos, 1, wheels.size() + 1) - 1;
        Wheel wheel = buildWheelWithSymbols(0, WHEEL_Y);
        wheels.add(index, wheel);
        repositionWheels();
        if (visible) wheel.makeVisible();
        updateJackpotDisplay();
        lastOk = true;
    }

    /**
     * Elimina la rueda en la posición indicada (clamped a {@code [1, n]}).
     * Falla si no hay ruedas.
     *
     * @param pos posición de la rueda a eliminar (base 1)
     */
    public void delWheel(int pos) {
        if (wheels.isEmpty()) { handleError("No hay ruedas para eliminar."); lastOk = false; return; }
        int index = clamp(pos, 1, wheels.size()) - 1;
        Wheel removed = wheels.remove(index);
        removed.makeInvisible();
        repositionWheels();
        updateJackpotDisplay();
        lastOk = true;
    }

    /**
     * Intercambia dos ruedas de posición.
     * Falla si no hay ruedas o los índices son iguales tras clamping.
     *
     * @param wheel1 posición de la primera rueda (base 1)
     * @param wheel2 posición de la segunda rueda (base 1)
     */
    public void swap(int wheel1, int wheel2) {
        if (wheels.isEmpty()) { handleError("No hay ruedas para intercambiar."); lastOk = false; return; }
        int i1 = clamp(wheel1, 1, wheels.size()) - 1;
        int i2 = clamp(wheel2, 1, wheels.size()) - 1;
        if (i1 == i2) { handleError("Las posiciones son la misma rueda."); lastOk = false; return; }
        Wheel tmp = wheels.get(i1);
        wheels.set(i1, wheels.get(i2));
        wheels.set(i2, tmp);
        repositionWheels();
        updateJackpotDisplay();
        lastOk = true;
    }

    /**
     * Fija la rueda indicada; no podrá girar hasta que se desbloquee.
     * Falla si no hay ruedas.
     *
     * @param wheel posición de la rueda (base 1)
     */
    public void lock(int wheel) {
        if (wheels.isEmpty()) { handleError("No hay ruedas."); lastOk = false; return; }
        int index = clamp(wheel, 1, wheels.size()) - 1;
        wheels.get(index).lock();
        lastOk = true;
    }

    /**
     * Libera la rueda indicada para que pueda volver a girar.
     * Falla si no hay ruedas.
     *
     * @param wheel posición de la rueda (base 1)
     */
    public void unlock(int wheel) {
        if (wheels.isEmpty()) { handleError("No hay ruedas."); lastOk = false; return; }
        int index = clamp(wheel, 1, wheels.size()) - 1;
        wheels.get(index).unlock();
        lastOk = true;
    }


    // --------------------------------------------------------------- símbolos

    /**
     * Agrega un símbolo en la posición indicada de la secuencia compartida.
     * Falla si el color ya existe.
     *
     * @param pos   posición de inserción (base 1)
     * @param color color CSS del nuevo símbolo
     */
    public void addSymbol(int pos, String color) {
        if (isColorUsed(color)) {
            handleError("El símbolo '" + color + "' ya existe.");
            lastOk = false;
            return;
        }
        int index = clamp(pos, 1, symbolColors.size() + 1) - 1;
        symbolColors.add(index, color);
        for (Wheel w : wheels) w.addSymbol(index + 1, color);
        updateJackpotDisplay();
        lastOk = true;
    }

    /**
     * Elimina el símbolo con el color indicado de todas las ruedas.
     * Falla si el color no existe.
     *
     * @param symbol color CSS del símbolo a eliminar
     */
    public void delSymbol(String symbol) {
        if (!isColorUsed(symbol)) {
            handleError("El símbolo '" + symbol + "' no existe.");
            lastOk = false;
            return;
        }
        symbolColors.remove(symbol);
        for (Wheel w : wheels) w.delSymbol(symbol);
        updateJackpotDisplay();
        lastOk = true;
    }

    // ------------------------------------------------------------------- giro

    /**
     * Posiciona la rueda indicada en el símbolo con el color dado.
     * Falla si no hay ruedas o el símbolo no existe en esa rueda.
     *
     * @param wheel  posición de la rueda (base 1)
     * @param symbol color CSS del símbolo destino
     */
    public void placeSymbol(int wheel, String symbol) {
        if (wheels.isEmpty()) { handleError("No hay ruedas."); lastOk = false; return; }
        int index = clamp(wheel, 1, wheels.size()) - 1;
        if (!wheels.get(index).placeSymbol(symbol)) {
            handleError("El símbolo '" + symbol + "' no está en la rueda " + wheel + ".");
            lastOk = false;
            return;
        }
        updateJackpotDisplay();
        lastOk = true;
    }

    /**
     * Avanza la rueda indicada un símbolo de forma circular.
     * Falla si no hay ruedas, no hay símbolos, o la rueda está bloqueada.
     *
     * @param wheel posición de la rueda (base 1)
     */
    public void spin(int wheel) {
        if (!validateSpinPreconditions()) return;
        int index = clamp(wheel, 1, wheels.size()) - 1;
        Wheel w = wheels.get(index);
        if (w.symbolCount() == 0) {
            handleError("La rueda " + wheel + " no tiene símbolos.");
            lastOk = false;
            return;
        }
        if (w.isLocked()) {
            handleError("La rueda " + wheel + " está bloqueada.");
            lastOk = false;
            return;
        }
        w.spin();
        updateJackpotDisplay();
        lastOk = true;
    }

    /**
     * Gira la rueda indicada {@code steps} posiciones. Anima si está visible.
     * Falla si no hay ruedas, símbolos, o la rueda está bloqueada.
     *
     * @param wheel posición de la rueda (base 1)
     * @param steps pasos a avanzar
     */
    public void spin(int wheel, int steps) {
        if (!validateSpinPreconditions()) return;
        int index = clamp(wheel, 1, wheels.size()) - 1;
        Wheel w = wheels.get(index);
        if (w.isLocked()) {
            handleError("La rueda " + wheel + " está bloqueada.");
            lastOk = false;
            return;
        }
        w.spin(steps);
        updateJackpotDisplay();
        lastOk = true;
    }

    /**
     * Coloca cada rueda en el símbolo indicado por {@code setSymbols}.
     * El arreglo debe tener un color por rueda (izquierda a derecha).
     * Falla si el tamaño no coincide o algún color no existe.
     *
     * @param setSymbols colores CSS, uno por rueda
     */
    public void spin(String[] setSymbols) {
        if (wheels.isEmpty()) { handleError("No hay ruedas."); lastOk = false; return; }
        if (setSymbols.length != wheels.size()) {
            handleError("El arreglo debe tener " + wheels.size() + " elemento(s).");
            lastOk = false;
            return;
        }
        boolean allOk = true;
        for (int i = 0; i < wheels.size(); i++) {
            if (!wheels.get(i).placeSymbol(setSymbols[i])) {
                handleError("El símbolo '" + setSymbols[i] + "' no existe en la rueda " + (i + 1) + ".");
                allOk = false;
            }
        }
        updateJackpotDisplay();
        lastOk = allOk;
    }


    /**
     * Avanza todas las ruedas un símbolo de forma circular.
     * Falla si no hay ruedas o no hay símbolos.
     */
    public void spin() {
        if (!validateSpinPreconditions()) return;
        for (Wheel w : wheels) w.spin();
        updateJackpotDisplay();
        lastOk = true;
    }

    // ---------------------------------------------------------------- consultas

    /**
     * Retorna los colores de todos los símbolos en orden de posición (base 1 primero).
     *
     * @return arreglo de colores CSS; vacío si no hay símbolos
     */
    public String[] symbols() {
        return symbolColors.toArray(new String[0]);
    }

    /**
     * Retorna la cantidad de símbolos distintos definidos en la máquina.
     *
     * @return número de símbolos
     */
    public int distinctSymbols() {
        return symbolColors.size();
    }

    /**
     * Retorna el color visible de cada rueda, de izquierda a derecha.
     *
     * @return arreglo de colores CSS; {@code null} en posiciones de ruedas vacías
     */
    public String[] configuration() {
        String[] config = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            config[i] = wheels.get(i).getVisibleColor();
        }
        return config;
    }

    /**
     * Indica si la máquina está en estado jackpot (todas las ruedas
     * muestran el mismo símbolo).
     *
     * @return {@code true} si hay jackpot; {@code false} en caso contrario
     */
    public boolean isJackpot() {
        if (wheels.isEmpty()) return false;
        String first = wheels.get(0).getVisibleColor();
        if (first == null) return false;
        for (Wheel w : wheels) {
            if (!first.equals(w.getVisibleColor())) return false;
        }
        return true;
    }

    // -------------------------------------------------------------- visibilidad

    /**
     * Muestra la ventana del canvas con todas las ruedas y símbolos.
     */
    public void makeVisible() {
        visible = true;
        resizeCanvas();
        view.makeVisible();
        for (Wheel w : wheels) w.makeVisible();
        updateJackpotDisplay();
        lastOk = true;
    }

    /**
     * Oculta la ventana del canvas. La lógica sigue funcionando en modo invisible.
     */
    public void makeInvisible() {
        for (Wheel w : wheels) w.makeInvisible();
        view.makeInvisible();
        visible = false;
        Canvas.setCanvasVisible(false);
        lastOk = true;
    }

    // ------------------------------------------------------------------ salida

    /**
     * Cierra la ventana del canvas y libera los recursos gráficos.
     */
    public void exit() {
        Canvas.setCanvasVisible(false);
        Canvas.getCanvas().close();
        lastOk = true;
    }

    // ------------------------------------------------------------------ estado

    /**
     * Indica si la última operación se realizó con éxito.
     *
     * @return {@code true} si la última operación fue exitosa
     */
    public boolean ok() {
        return lastOk;
    }

    // ---------------------------------------------------------------- privados

    /** Crea una rueda en ({@code x},{@code y}) y la rellena con la secuencia de símbolos. */
    private Wheel buildWheelWithSymbols(int x, int y) {
        Wheel wheel = new Wheel(x, y);
        for (int i = 0; i < symbolColors.size(); i++) {
            wheel.addSymbol(i + 1, symbolColors.get(i));
        }
        return wheel;
    }

    /** Recalcula la posición x de cada rueda y redimensiona el canvas. */
    private void repositionWheels() {
        for (int i = 0; i < wheels.size(); i++) {
            wheels.get(i).moveTo(MARGIN + i * (Wheel.WIDTH + WHEEL_GAP), WHEEL_Y);
        }
        resizeCanvas();
    }

    /** Ajusta el tamaño del canvas y la vista al número actual de ruedas. No actúa en modo invisible. */
    private void resizeCanvas() {
        if (!visible) return;
        int n = Math.max(1, wheels.size());
        int w = Math.max(MIN_CANVAS_W, MARGIN + n * (Wheel.WIDTH + WHEEL_GAP) + MARGIN);
        Canvas.getCanvas().resize(w, CANVAS_H);
        view.resize(w, CANVAS_H);
    }

    /** Muestra u oculta el banner de jackpot según el estado actual. */
    private void updateJackpotDisplay() {
        if (isJackpot()) { view.showJackpot(); } else { view.hideJackpot(); }
    }

    /**
     * Verifica que haya ruedas y símbolos antes de girar.
     * Establece {@code lastOk = false} y muestra error si falla.
     *
     * @return {@code true} si las precondiciones se cumplen
     */
    private boolean validateSpinPreconditions() {
        if (wheels.isEmpty())       { handleError("La máquina no tiene ruedas.");   lastOk = false; return false; }
        if (symbolColors.isEmpty()) { handleError("La máquina no tiene símbolos."); lastOk = false; return false; }
        return true;
    }

    /** Retorna {@code true} si el color ya está en la secuencia de símbolos. */
    private boolean isColorUsed(String color) {
        return symbolColors.contains(color);
    }

    /** Muestra un diálogo de error solo si el simulador está visible. */
    private void handleError(String message) {
        if (visible) {
            JOptionPane.showMessageDialog(null, message, "Slot Machine — Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Limita {@code val} al rango {@code [min, max]}. */
    private int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(val, max));
    }
}
